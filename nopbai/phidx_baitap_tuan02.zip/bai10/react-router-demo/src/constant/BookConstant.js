
export const BookConstant = {

    BOOK_BASE_URL : '  http://localhost:8080/v1/api/books',
    GET_DETAIL_BOOK : 'http://localhost:8080/v1/api/books/?id=',
    CATEGORIES_BASE_URL : 'http://localhost:8080/v1/api/categories',
    PAGINATION_PAGE : 'http://localhost:8080/v1/api/books?'
}
