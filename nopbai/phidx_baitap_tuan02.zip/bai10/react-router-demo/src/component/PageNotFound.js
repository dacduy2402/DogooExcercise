import React, { Component } from 'react'

export default class PageNotFound extends Component {
    render() {
        return (
            <div className="alert alert-danger" role="alert">
               Page Not Found
            </div>
        )
    }
}
